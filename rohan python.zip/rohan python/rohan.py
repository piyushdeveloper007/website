# a='"Hello Everyone"'
# a="Hello Everyone"
# b="ok"
# print(a[1:5])
# print(a*2)
# print(c)
# print(a*50)
# a=[12,12,13,1]
# print(a)
# print(type(a))
# print(a*10)
# # a.sort(reverse=True)
# a=["neha","rohan","vivek","raju"]
# a[1]="Ramesh"
# # a.sort()
# print(a*10)
a=[11,1,2,3,3,3,4,4,5,5,6,7,8,9,10]
# # print(a.count(5))
# b=[11,12,13,14]
# a.append(b)
# a.extend(b)
# a.reverse()
# a.sort(reverse=True)
# a.pop(4)
# a.clear()
# a.remove(10)
# a.insert(1,"rajaji")
# print(a.index(5))
# a ="hello"
a.index(-1)
# print(a)
# c="madam"
# print(c[::-1])

# a = [2,55,678,5678]
# print(a[-1])
